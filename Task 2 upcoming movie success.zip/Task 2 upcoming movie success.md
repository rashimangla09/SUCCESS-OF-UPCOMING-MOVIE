```python
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
import warnings
warnings.filterwarnings("ignore")
```


```python
df = pd.read_csv('Movie-test.csv')
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>adipurush</td>
      <td>mythological action film</td>
      <td>based on hindu book ramayana</td>
      <td>om raut</td>
      <td>prabha,kriti sanon,saif ali khan,sunny singh</td>
      <td>2023</td>
      <td>174</td>
      <td>3.7</td>
      <td>95124</td>
      <td>450.00</td>
      <td>45</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>darlings</td>
      <td>comedy</td>
      <td>the pervasive social ill of domestic violence</td>
      <td>jasmeet k reen</td>
      <td>alia bhatt,shefali shah,vijay varma</td>
      <td>2022</td>
      <td>133</td>
      <td>6.6</td>
      <td>19832</td>
      <td>47.00</td>
      <td>32</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>tu jhooti main makkar</td>
      <td>romantic comedy</td>
      <td>romantic relationship</td>
      <td>luv ranjan</td>
      <td>ranbir kapoor,sharadha kapoor</td>
      <td>2023</td>
      <td>150</td>
      <td>6.1</td>
      <td>21887</td>
      <td>215.00</td>
      <td>38</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>zara hatke zara bachke</td>
      <td>romantic comedy</td>
      <td>NaN</td>
      <td>laxman utekar</td>
      <td>sara ali khan,vicky kaushal,bony kapoor</td>
      <td>2023</td>
      <td>140</td>
      <td>7.7</td>
      <td>8098</td>
      <td>83.78</td>
      <td>64</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>love again</td>
      <td>romance,Sci-Fi</td>
      <td>NaN</td>
      <td>james c. strouse</td>
      <td>priyanka chopra,nick jhons,sam haughen</td>
      <td>2023</td>
      <td>104</td>
      <td>5.7</td>
      <td>5200</td>
      <td>90.00</td>
      <td>57</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (20, 12)




```python
df.isnull().sum()
```




    Rank                  0
    Title                 0
    Genre                 0
    Description           2
    Director              0
    Actors                0
    Year                  0
    Runtime (Minutes)     0
    Rating                0
    Votes                 0
    Revenue (Millions)    1
    Metascore             0
    dtype: int64




```python
sns.heatmap(df.isnull())
```




    <Axes: >




    
![png](output_4_1.png)
    



```python
df.dropna(axis=0,inplace=True)
```


```python
dup_df = df.duplicated().any()
print("Are there any duplicate values?", dup_df)
```

    Are there any duplicate values? False
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>17.000000</td>
      <td>17.000000</td>
      <td>17.000000</td>
      <td>17.000000</td>
      <td>17.000000</td>
      <td>17.000000</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>11.352941</td>
      <td>2017.176471</td>
      <td>125.705882</td>
      <td>7.047059</td>
      <td>138334.294118</td>
      <td>173.710000</td>
      <td>62.647059</td>
    </tr>
    <tr>
      <th>std</th>
      <td>5.988960</td>
      <td>2.627625</td>
      <td>19.996139</td>
      <td>1.139692</td>
      <td>106424.582823</td>
      <td>154.234184</td>
      <td>17.531904</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2016.000000</td>
      <td>87.000000</td>
      <td>3.700000</td>
      <td>7188.000000</td>
      <td>2.870000</td>
      <td>32.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>7.000000</td>
      <td>2016.000000</td>
      <td>116.000000</td>
      <td>6.600000</td>
      <td>56036.000000</td>
      <td>51.690000</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>12.000000</td>
      <td>2016.000000</td>
      <td>127.000000</td>
      <td>7.100000</td>
      <td>118151.000000</td>
      <td>151.060000</td>
      <td>66.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>16.000000</td>
      <td>2016.000000</td>
      <td>133.000000</td>
      <td>7.900000</td>
      <td>211760.000000</td>
      <td>234.020000</td>
      <td>74.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>20.000000</td>
      <td>2023.000000</td>
      <td>174.000000</td>
      <td>8.300000</td>
      <td>340798.000000</td>
      <td>532.170000</td>
      <td>93.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
df['Runtime (Minutes)']>=120
```




    0      True
    1      True
    2      True
    5     False
    6      True
    8      True
    9     False
    10     True
    11     True
    12     True
    13    False
    14    False
    15    False
    16     True
    17     True
    18    False
    19    False
    Name: Runtime (Minutes), dtype: bool




```python
df[df['Runtime (Minutes)']>=120]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>adipurush</td>
      <td>mythological action film</td>
      <td>based on hindu book ramayana</td>
      <td>om raut</td>
      <td>prabha,kriti sanon,saif ali khan,sunny singh</td>
      <td>2023</td>
      <td>174</td>
      <td>3.7</td>
      <td>95124</td>
      <td>450.00</td>
      <td>45</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>darlings</td>
      <td>comedy</td>
      <td>the pervasive social ill of domestic violence</td>
      <td>jasmeet k reen</td>
      <td>alia bhatt,shefali shah,vijay varma</td>
      <td>2022</td>
      <td>133</td>
      <td>6.6</td>
      <td>19832</td>
      <td>47.00</td>
      <td>32</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>tu jhooti main makkar</td>
      <td>romantic comedy</td>
      <td>romantic relationship</td>
      <td>luv ranjan</td>
      <td>ranbir kapoor,sharadha kapoor</td>
      <td>2023</td>
      <td>150</td>
      <td>6.1</td>
      <td>21887</td>
      <td>215.00</td>
      <td>38</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>La La Land</td>
      <td>Comedy,Drama,Music</td>
      <td>A jazz pianist falls for an aspiring actress i...</td>
      <td>Damien Chazelle</td>
      <td>Ryan Gosling, Emma Stone, Rosemarie DeWitt, J....</td>
      <td>2016</td>
      <td>128</td>
      <td>8.3</td>
      <td>258682</td>
      <td>151.06</td>
      <td>93</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>The Lost City of Z</td>
      <td>Action,Adventure,Biography</td>
      <td>A true-life drama, centering on British explor...</td>
      <td>James Gray</td>
      <td>Charlie Hunnam, Robert Pattinson, Sienna Mille...</td>
      <td>2016</td>
      <td>141</td>
      <td>7.1</td>
      <td>7188</td>
      <td>8.01</td>
      <td>78</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>Fantastic Beasts and Where to Find Them</td>
      <td>Adventure,Family,Fantasy</td>
      <td>The adventures of writer Newt Scamander in New...</td>
      <td>David Yates</td>
      <td>Eddie Redmayne, Katherine Waterston, Alison Su...</td>
      <td>2016</td>
      <td>133</td>
      <td>7.5</td>
      <td>232072</td>
      <td>234.02</td>
      <td>66</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>Hidden Figures</td>
      <td>Biography,Drama,History</td>
      <td>The story of a team of female African-American...</td>
      <td>Theodore Melfi</td>
      <td>Taraji P. Henson, Octavia Spencer, Janelle Mon...</td>
      <td>2016</td>
      <td>127</td>
      <td>7.8</td>
      <td>93103</td>
      <td>169.27</td>
      <td>74</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>Rogue One</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>The Rebel Alliance makes a risky move to steal...</td>
      <td>Gareth Edwards</td>
      <td>Felicity Jones, Diego Luna, Alan Tudyk, Donnie...</td>
      <td>2016</td>
      <td>133</td>
      <td>7.9</td>
      <td>323118</td>
      <td>532.17</td>
      <td>65</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>Hacksaw Ridge</td>
      <td>Biography,Drama,History</td>
      <td>WWII American Army Medic Desmond T. Doss, who ...</td>
      <td>Mel Gibson</td>
      <td>Andrew Garfield, Sam Worthington, Luke Bracey,...</td>
      <td>2016</td>
      <td>139</td>
      <td>8.2</td>
      <td>211760</td>
      <td>67.12</td>
      <td>71</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>Jason Bourne</td>
      <td>Action,Thriller</td>
      <td>The CIA's most dangerous former operative is d...</td>
      <td>Paul Greengrass</td>
      <td>Matt Damon, Tommy Lee Jones, Alicia Vikander,V...</td>
      <td>2016</td>
      <td>123</td>
      <td>6.7</td>
      <td>150823</td>
      <td>162.16</td>
      <td>58</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby('Year')['Votes'].mean()
```




    Year
    2016    158202.857143
    2022     19832.000000
    2023     58505.500000
    Name: Votes, dtype: float64




```python
df.groupby('Year')['Votes'].mean().sort_values(ascending=False)
```




    Year
    2016    158202.857143
    2023     58505.500000
    2022     19832.000000
    Name: Votes, dtype: float64




```python
df.groupby('Year')['Revenue (Millions)'].mean().sort_values(ascending=False)
```




    Year
    2023    332.500000
    2016    160.076429
    2022     47.000000
    Name: Revenue (Millions), dtype: float64




```python
x = df[['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
       'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
       'Metascore']]
```


```python
y = df[['Rating']]
```


```python
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=42)
```


```python
from sklearn.linear_model import LogisticRegression

```


```python
log = LogisticRegression

```


```python
log.score
```




    <function sklearn.base.ClassifierMixin.score(self, X, y, sample_weight=None)>




```python
log.fit
```




    <function sklearn.linear_model._logistic.LogisticRegression.fit(self, X, y, sample_weight=None)>




```python
from sklearn.metrics import confusion_matrix
```


```python
print(x_train.shape)
```

    (13, 12)
    


```python
print(x_test.shape)
```

    (4, 12)
    


```python
print(y_train.shape)
```

    (13, 1)
    


```python
print(y_test.shape)
```

    (4, 1)
    


```python
variables = df.columns.tolist()
print("Variables:")
print(variables)
```

    Variables:
    ['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year', 'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)', 'Metascore']
    


```python
numerical_vars = []
categorical_vars = []
for var in df.columns:
    if df[var].dtype in ['int64','float64']:
        numerical_vars.append(var)
    else:
        categorical_vars.append(var)
        
print("Numerical variables:")  
print(numerical_vars)
print("Categorical variables:")
print(categorical_vars)
```

    Numerical variables:
    ['Rank', 'Year', 'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)', 'Metascore']
    Categorical variables:
    ['Title', 'Genre', 'Description', 'Director', 'Actors']
    


```python
numerical_vars = ['Rank', 'Year', 'Runtime (Minutes)',  'Votes', 'Metascore']
df[numerical_vars] = df[numerical_vars].astype(int)
```


```python
decimal_vars = ['Rating','Revenue (Millions)']
df[decimal_vars] = df[decimal_vars].astype(float)
```


```python
print('updated data types:')
print(df.dtypes)
```

    updated data types:
    Rank                    int32
    Title                  object
    Genre                  object
    Description            object
    Director               object
    Actors                 object
    Year                    int32
    Runtime (Minutes)       int32
    Rating                float64
    Votes                   int32
    Revenue (Millions)    float64
    Metascore               int32
    dtype: object
    


```python
summary_stats = df.describe()
print("Summary Statistics:")
print(summary_stats)
```

    Summary Statistics:
                Rank         Year  Runtime (Minutes)     Rating          Votes  \
    count  17.000000    17.000000          17.000000  17.000000      17.000000   
    mean   11.352941  2017.176471         125.705882   7.047059  138334.294118   
    std     5.988960     2.627625          19.996139   1.139692  106424.582823   
    min     1.000000  2016.000000          87.000000   3.700000    7188.000000   
    25%     7.000000  2016.000000         116.000000   6.600000   56036.000000   
    50%    12.000000  2016.000000         127.000000   7.100000  118151.000000   
    75%    16.000000  2016.000000         133.000000   7.900000  211760.000000   
    max    20.000000  2023.000000         174.000000   8.300000  340798.000000   
    
           Revenue (Millions)  Metascore  
    count           17.000000  17.000000  
    mean           173.710000  62.647059  
    std            154.234184  17.531904  
    min              2.870000  32.000000  
    25%             51.690000  45.000000  
    50%            151.060000  66.000000  
    75%            234.020000  74.000000  
    max            532.170000  93.000000  
    


```python

plt.figure(figsize=(12,8))
df[numerical_vars].hist(bins = 20)
plt.tight_layout
plt.show()
```


    <Figure size 1200x800 with 0 Axes>



    
![png](output_32_1.png)
    



```python
for var in categorical_vars:
    plt.figure(figsize=(12,8))
    df[var].value_counts().plot(kind='bar')
    plt.title(var)
    plt.xlabel(var)
    plt.ylabel('count')
    plt.show()
```


    
![png](output_33_0.png)
    



    
![png](output_33_1.png)
    



    
![png](output_33_2.png)
    



    
![png](output_33_3.png)
    



    
![png](output_33_4.png)
    



```python
print("Fragmentation in 'Title' column:")
print(df['Title'].unique())
```

    Fragmentation in 'Title' column:
    ['adipurush' 'darlings' 'tu jhooti main makkar' 'The Great Wall'
     'La La Land' 'The Lost City of Z' 'Passengers'
     'Fantastic Beasts and Where to Find Them' 'Hidden Figures' 'Rogue One'
     'Moana' 'Colossal' 'The Secret Life of Pets' 'Hacksaw Ridge'
     'Jason Bourne' 'Lion' 'Arrival']
    


```python
print("Fragmentation in 'Director' column:")
print(df['Director'].unique())
```

    Fragmentation in 'Director' column:
    ['om raut' 'jasmeet k reen' 'luv ranjan' 'Yimou Zhang' 'Damien Chazelle'
     'James Gray' 'Morten Tyldum' 'David Yates' 'Theodore Melfi'
     'Gareth Edwards' 'Ron Clements' 'Nacho Vigalondo' 'Chris Renaud'
     'Mel Gibson' 'Paul Greengrass' 'Garth Davis' 'Denis Villeneuve']
    


```python
print("Fragmentation in 'Actors' column:")
print(df['Actors'].unique())
```

    Fragmentation in 'Actors' column:
    ['prabha,kriti sanon,saif ali khan,sunny singh'
     'alia bhatt,shefali shah,vijay varma' 'ranbir kapoor,sharadha kapoor'
     'Matt Damon, Tian Jing, Willem Dafoe, Andy Lau'
     'Ryan Gosling, Emma Stone, Rosemarie DeWitt, J.K. Simmons'
     'Charlie Hunnam, Robert Pattinson, Sienna Miller, Tom Holland'
     'Jennifer Lawrence, Chris Pratt, Michael Sheen,Laurence Fishburne'
     'Eddie Redmayne, Katherine Waterston, Alison Sudol,Dan Fogler'
     'Taraji P. Henson, Octavia Spencer, Janelle Monáe,Kevin Costner'
     'Felicity Jones, Diego Luna, Alan Tudyk, Donnie Yen'
     "Auli'i Cravalho, Dwayne Johnson, Rachel House, Temuera Morrison"
     'Anne Hathaway, Jason Sudeikis, Austin Stowell,Tim Blake Nelson'
     'Louis C.K., Eric Stonestreet, Kevin Hart, Lake Bell'
     'Andrew Garfield, Sam Worthington, Luke Bracey,Teresa Palmer'
     'Matt Damon, Tommy Lee Jones, Alicia Vikander,Vincent Cassel'
     'Dev Patel, Nicole Kidman, Rooney Mara, Sunny Pawar'
     'Amy Adams, Jeremy Renner, Forest Whitaker,Michael Stuhlbarg']
    


```python
df['Title']=df['Title'].str.strip()
df['Director']=df['Director'].str.strip()
df['Actors']=df['Actors'].str.strip()
df['Actors']=df['Actors'].str.replace(",",",")
```


```python
print("Fixed 'Title' column:")
print(df['Title'].unique())
print("Fixed 'Director' column:")
print(df['Director'].unique())
print("Fixed 'Actors' column:")
print(df['Actors'].unique())
```

    Fixed 'Title' column:
    ['adipurush' 'darlings' 'tu jhooti main makkar' 'The Great Wall'
     'La La Land' 'The Lost City of Z' 'Passengers'
     'Fantastic Beasts and Where to Find Them' 'Hidden Figures' 'Rogue One'
     'Moana' 'Colossal' 'The Secret Life of Pets' 'Hacksaw Ridge'
     'Jason Bourne' 'Lion' 'Arrival']
    Fixed 'Director' column:
    ['om raut' 'jasmeet k reen' 'luv ranjan' 'Yimou Zhang' 'Damien Chazelle'
     'James Gray' 'Morten Tyldum' 'David Yates' 'Theodore Melfi'
     'Gareth Edwards' 'Ron Clements' 'Nacho Vigalondo' 'Chris Renaud'
     'Mel Gibson' 'Paul Greengrass' 'Garth Davis' 'Denis Villeneuve']
    Fixed 'Actors' column:
    ['prabha,kriti sanon,saif ali khan,sunny singh'
     'alia bhatt,shefali shah,vijay varma' 'ranbir kapoor,sharadha kapoor'
     'Matt Damon, Tian Jing, Willem Dafoe, Andy Lau'
     'Ryan Gosling, Emma Stone, Rosemarie DeWitt, J.K. Simmons'
     'Charlie Hunnam, Robert Pattinson, Sienna Miller, Tom Holland'
     'Jennifer Lawrence, Chris Pratt, Michael Sheen,Laurence Fishburne'
     'Eddie Redmayne, Katherine Waterston, Alison Sudol,Dan Fogler'
     'Taraji P. Henson, Octavia Spencer, Janelle Monáe,Kevin Costner'
     'Felicity Jones, Diego Luna, Alan Tudyk, Donnie Yen'
     "Auli'i Cravalho, Dwayne Johnson, Rachel House, Temuera Morrison"
     'Anne Hathaway, Jason Sudeikis, Austin Stowell,Tim Blake Nelson'
     'Louis C.K., Eric Stonestreet, Kevin Hart, Lake Bell'
     'Andrew Garfield, Sam Worthington, Luke Bracey,Teresa Palmer'
     'Matt Damon, Tommy Lee Jones, Alicia Vikander,Vincent Cassel'
     'Dev Patel, Nicole Kidman, Rooney Mara, Sunny Pawar'
     'Amy Adams, Jeremy Renner, Forest Whitaker,Michael Stuhlbarg']
    


```python
from sklearn.preprocessing import LabelEncoder , OneHotEncoder
```


```python
label_encoder = LabelEncoder()
onehot_encoder = OneHotEncoder(sparse = False)
```


```python
categorical_columns = ['Title', 'Genre', 'Description', 'Director', 'Actors']
for column in categorical_columns:
    df[column] = label_encoder.fit_transform(df[column])
```


```python
df ['Success Rate'] = df ['Revenue (Millions)']
```


```python
top_movies_revenue = df.nlargest(5, 'Revenue (Millions)')
print("Top 5 movies ny Revenue:")
print(top_movies_revenue[['Title','Revenue (Millions)']])
```

    Top 5 movies ny Revenue:
        Title  Revenue (Millions)
    12     10              532.17
    0      14              450.00
    15     13              368.31
    13      8              248.75
    10      2              234.02
    


```python
df_encoded = pd.get_dummies(df, columns = ['Rating'])
print("Encoded dataset")
print(df_encoded.head())
```

    Encoded dataset
       Rank  Title  Genre  Description  Director  Actors  Year  Runtime (Minutes)  \
    0     1     14     13           14        16      15  2023                174   
    1     2     15     12           16        14      14  2022                133   
    2     3     16     14           15        15      16  2023                150   
    5     6     11      1            4        13      10  2016                103   
    6     7      6     10            1         1      12  2016                128   
    
        Votes  Revenue (Millions)  ...  Rating_7.0  Rating_7.1  Rating_7.5  \
    0   95124              450.00  ...       False       False       False   
    1   19832               47.00  ...       False       False       False   
    2   21887              215.00  ...       False       False       False   
    5   56036               45.13  ...       False       False       False   
    6  258682              151.06  ...       False       False       False   
    
       Rating_7.7  Rating_7.8  Rating_7.9  Rating_8.0  Rating_8.1  Rating_8.2  \
    0       False       False       False       False       False       False   
    1       False       False       False       False       False       False   
    2       False       False       False       False       False       False   
    5       False       False       False       False       False       False   
    6       False       False       False       False       False       False   
    
       Rating_8.3  
    0       False  
    1       False  
    2       False  
    5       False  
    6        True  
    
    [5 rows x 27 columns]
    


```python
encoded_columns = df_encoded.columns.tolist()
print("Encoded columns:")
print(encoded_columns)
```

    Encoded columns:
    ['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year', 'Runtime (Minutes)', 'Votes', 'Revenue (Millions)', 'Metascore', 'Success Rate', 'Rating_3.7', 'Rating_6.1', 'Rating_6.4', 'Rating_6.6', 'Rating_6.7', 'Rating_7.0', 'Rating_7.1', 'Rating_7.5', 'Rating_7.7', 'Rating_7.8', 'Rating_7.9', 'Rating_8.0', 'Rating_8.1', 'Rating_8.2', 'Rating_8.3']
    


```python
for columns in encoded_columns:
    unique_values = df_encoded[column].unique()
    print(unique_values)
    print()
```

    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    [15 14 16 10 12  4  8  6 13  7  3  2  9  1 11  5  0]
    
    


```python
success_columns = ['Runtime (Minutes)', 'Votes', 'Rating', 'Revenue (Millions)']
```


```python
successful_movies =df[df['Metascore']==1]
success_means = successful_movies[success_columns].mean()
```


```python
unsuccessful_movies = df[df['Metascore']==0]
unsuccessful_means = unsuccessful_movies[success_columns].mean()
```


```python
print("Average values for successful movies:")
print(success_means)
print()
```

    Average values for successful movies:
    Runtime (Minutes)    NaN
    Votes                NaN
    Rating               NaN
    Revenue (Millions)   NaN
    dtype: float64
    
    


```python
print("Average values for unsuccessful movies:")
print(unsuccessful_means)
print()
```

    Average values for unsuccessful movies:
    Runtime (Minutes)    NaN
    Votes                NaN
    Rating               NaN
    Revenue (Millions)   NaN
    dtype: float64
    
    


```python
genre_success_rate = df.groupby('Genre')['Success Rate'].mean().sort_values
```


```python
plt.figure(figsize = (12,8))
plt.title('Genre-wise Success Rate of Movies')
plt.xlabel('Genre')
plt.ylabel('Success Rate')
plt.xticks(rotation = 90 )
plt.tight_layout()
plt.show()
```


    
![png](output_53_0.png)
    



```python

```
